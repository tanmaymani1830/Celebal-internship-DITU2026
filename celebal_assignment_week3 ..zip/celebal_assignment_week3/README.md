# Superstore Sales Analysis (SQL) — Celebal Assignment Week 3

SQL-based analysis of the Sample Superstore dataset covering data normalization,
subqueries, CTEs, and window functions to uncover customer sales patterns.

## Project Structure

```
celebal_assignment_week3/
├── Sample_-_Superstore.csv       # Raw dataset
├── superstore_analysis.sql       # All SQL queries (schema, inserts, analysis)
├── superstore_sql_analysis.pdf   # Write-up of the analysis
├── screenshots/                  # Query result screenshots
│   ├── above_avg_sales.png
│   ├── cte_total_sales.png
│   ├── customer_ranking.png
│   ├── single_order_customers.png
│   └── top_customers.png
└── README.md
```

## What the SQL does

1. **Normalization** — splits the flat superstore CSV into `customers`, `products`,
   and `orders` tables.
2. **Subqueries** — orders above average sales, highest order value per customer.
3. **CTEs** — total sales per customer computed via `WITH customer_sales AS (...)`.
4. **Window functions** — `RANK()` and `ROW_NUMBER()` for customer/order ranking.
5. **Business queries** — top 5 / bottom 5 customers, single-order customers,
   customers above average sales.

## Key Insights

- A small group of customers drives most of total sales — high dependency on
  top-value customers.
- Ranking via `RANK()` shows a steep drop-off in revenue after the top few customers.
- Most individual transactions fall below the average sale value; high-value
  orders are relatively rare.
- Many customers place only a single order, pointing to weak repeat business.
- Overall sales distribution is concentrated and uneven across the customer base.

See `superstore_sql_analysis.pdf` for the full write-up.

## Tech Used

- MySQL (CTEs, window functions, subqueries, joins)

CREATE DATABASE celebal_assignment_week3;
USE celebal_assignment_week3;

 # 1. CREATE NORMALIZED TABLES

#Customers table stores unique customer details

CREATE TABLE customers (
    customer_id VARCHAR(50),
    customer_name VARCHAR(255),
    segment VARCHAR(50)
);

#Products table stores product information

CREATE TABLE products (
    product_id VARCHAR(50),
    category VARCHAR(100),
    sub_category VARCHAR(100),
    product_name VARCHAR(255)
);

#Orders table stores transaction data

CREATE TABLE orders (
    order_id VARCHAR(50),
    order_date DATE,
    customer_id VARCHAR(50),
    product_id VARCHAR(50),
    sales DECIMAL(10,2),
    quantity INT,
    profit DECIMAL(10,2)
);

# 2. INSERT DATA FROM RAW TABLE

#Insert unique customers

INSERT INTO customers
SELECT DISTINCT
    `Customer ID`,
    `Customer Name`,
    `Segment`
FROM `sample - superstore`;

#Insert unique products

INSERT INTO products
SELECT DISTINCT
    `Product ID`,
    `Category`,
    `Sub-Category`,
    `Product Name`
FROM `sample - superstore`;


#Insert all order transactions 

CREATE TABLE orders_clean AS
SELECT
    `Order ID` AS order_id,
    STR_TO_DATE(`Order Date`, '%m/%e/%Y') AS order_date,
    `Customer ID` AS customer_id,
    `Product ID` AS product_id,
    `Sales` AS sales,
    `Quantity` AS quantity,
    `Profit` AS profit
FROM `sample - superstore`;

# 3.SUBQUERY ANALYSIS

# Orders having above average sales
SELECT *
FROM orders
WHERE sales > (SELECT AVG(sales) FROM orders);

 # Highest order value per customer
SELECT o.*
FROM orders o
JOIN (
    SELECT customer_id, MAX(sales) AS max_sales
    FROM orders
    GROUP BY customer_id
) m
ON o.customer_id = m.customer_id
AND o.sales = m.max_sales;

# 4. CTE (COMMON TABLE EXPRESSION)

WITH customer_sales AS (
    SELECT 
        customer_id,
        SUM(sales) AS total_sales
    FROM orders
    GROUP BY customer_id
)
SELECT * FROM customer_sales;

# 5. WINDOW FUNCTIONS

 # Rank customers based on total sales
SELECT 
    customer_id,
    SUM(sales) AS total_sales,
    RANK() OVER (ORDER BY SUM(sales) DESC) AS sales_rank
FROM orders
GROUP BY customer_id;

# Row number for each order of a customer (highest sales first)
SELECT 
    customer_id,
    order_id,
    sales,
    ROW_NUMBER() OVER (PARTITION BY customer_id ORDER BY sales DESC) AS rn
FROM orders;


 # FINAL ANALYSIS (JOIN + CTE + RANK)
 
 # Customer ranking with names and total sales
 
 WITH customer_sales AS (
    SELECT 
        customer_id,
        SUM(sales) AS total_sales
    FROM orders
    GROUP BY customer_id
),
ranked_customers AS (
    SELECT 
        customer_id,
        total_sales,
        RANK() OVER (ORDER BY total_sales DESC) AS rnk
    FROM customer_sales
    )
SELECT 
    c.customer_id,
    c.customer_name,
    r.total_sales,
    r.rnk
FROM ranked_customers r
JOIN customers c
ON c.customer_id = r.customer_id;


 # 7. BUSINESS QUERIES
 
 # Top 5 customers by sales
 SELECT *
FROM (
    SELECT 
        customer_id,
        SUM(sales) AS total_sales
    FROM orders
    GROUP BY customer_id
) t
ORDER BY total_sales DESC
LIMIT 5;

# Bottom 5 customers
SELECT *
FROM (
    SELECT 
        customer_id,
        SUM(sales) AS total_sales
    FROM orders
    GROUP BY customer_id
) t
ORDER BY total_sales ASC
LIMIT 5;

# Customers with only one order
SELECT customer_id
FROM orders
GROUP BY customer_id
HAVING COUNT(order_id) = 1;

# Customers above average sales
SELECT customer_id, SUM(sales) AS total_sales
FROM orders
GROUP BY customer_id
HAVING SUM(sales) > (SELECT AVG(sales) FROM orders);